package com.claim.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.claim.entity.User;

@Service
public class UserService {
	

	
	ArrayList<User> listUser = new ArrayList<>();
	
	public void saveUser(User user) {
		
		listUser.add(user);
	
		
	}
	
	public User handleLogin(User user) {
		for(int i = 0; i < listUser.size(); i++) {
			User tempUser = listUser.get(i);
			System.out.println("in handleLogin");
			if(tempUser.getEmail().equals(user.getEmail()) && tempUser.getPassword().equals(user.getPassword())) {
				return tempUser;
			}
		}
		return null;
	}
	
	


	
	
	
	public ArrayList<User> getUserList(){
		return listUser;
	}

}

package com.claim.repository;

import org.springframework.stereotype.Repository;

import com.claim.entity.Orders;
import com.claim.entity.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OrdersRepository extends JpaRepository<Orders, String>{
	
	
	@Query("SELECT O FROM Orders O WHERE O.article = ?1")
	Orders findOrdersbyArticle(String article);
	
	@Query("SELECT O FROM Orders O WHERE O.article = ?1 and O.article = ?2")
	Orders lookUp(String article, String price);
	
	@Query("SELECT O FROM Orders O WHERE O.article= ?1")
	Orders lookUp(String article);

}

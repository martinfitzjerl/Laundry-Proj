package com.claim.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.claim.entity.Orders;
import com.claim.entity.User;
import com.claim.repository.OrdersRepository;
import com.claim.repository.UserRepository;
import com.claim.service.sendMail;

@CrossOrigin
//@RestController
@Controller
public class UserController {
	
	@Autowired
	UserService userSrv;
	

	@Autowired
	OrdersService ordersSrv;
	
	@Autowired
	OrdersRepository ordersRep;
	
	@Autowired
	UserRepository userRep;
	
	@Autowired
	sendMail sMail;
	
	
	@GetMapping("/")
	public String welcome(Model model) {
		
		return "index";
	}
	
	
	
	
	@PostMapping("/sign-up")
	public String handleSignUp(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("user", user);
			userSrv.saveUser(user);
			userRep.save(user);
			sMail.send("claimtest33@gmail.com", "thanks for signing up", "You logged in");
		return "thank-you";
	}

	
	@GetMapping("/sign-up")
    public ModelAndView signUp(Model model) {
		return new ModelAndView("sign-up", "user", new User());
		
	}
	
	@PostMapping("/location")
	public String handleLocation(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("user", user);
			userSrv.saveUser(user);
			userRep.save(user);

		return "location";
	}

	
	@GetMapping("/location")
    public ModelAndView location(Model model) {
		return new ModelAndView("location", "user", new User());
		
	}
	
	
	
	
	@PostMapping("/pricing")
	public String handlePricing(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("user", user);
			userRep.save(user);
			userSrv.saveUser(user);

		return "pricing";
	}

	
	@GetMapping("/pricing")
    public ModelAndView pricing(Model model) {
		return new ModelAndView("pricing", "user", new User());
		
	}
	
	
	@PostMapping("/login")
	public String handleLogin(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("user", user);
			userSrv.saveUser(user);
			userRep.save(user);
			
			User tempUser = userSrv.handleLogin(user);
			
			if(tempUser == null) {
			model.addAttribute("error", "Invalid login");
			System.out.println("in handleLogin");
			return "pricing";
			
			
		}
		
return "home";

	}

	
	@GetMapping("/login")
    public ModelAndView login(Model model) {
		return new ModelAndView("login", "user", new User()); 
	}
	
	
	@PostMapping("/home")
	public String handleHome(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("user", user);

		return "home";
	}
	
	@GetMapping("/home")
	public ModelAndView home(Model model) {
		return new ModelAndView("home", "user", new User());


	}
	
	
	@PostMapping("/contact")
	public String handleContact(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("user", user);
			userRep.save(user);
			userSrv.saveUser(user);

		return "contact";
	}
	
	@GetMapping("/contact")
	public ModelAndView contact(Model model) {
		return new ModelAndView("contact", "user", new User());

	}
	

	
	

	
	
	@RequestMapping(value="/userList", 
	         consumes=MediaType.APPLICATION_JSON_VALUE, 
	         produces=MediaType.APPLICATION_JSON_VALUE,
	         method= RequestMethod.GET
	         )
	public List<User> listAllStudents(){
		return userRep.findAll();
	}

	@GetMapping("/userList")
	public String userList(Model model) {
		
		ArrayList<User> userList = userSrv.getUserList();
		
		model.addAttribute("userList", userList);
		
		return "userList";

	}
	
	



}

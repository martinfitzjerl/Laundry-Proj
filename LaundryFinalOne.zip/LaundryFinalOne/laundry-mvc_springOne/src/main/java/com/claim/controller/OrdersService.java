package com.claim.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.claim.entity.Orders;
import com.claim.entity.User;

@Service
public class OrdersService {
	

	
	ArrayList<Orders> listOrders = new ArrayList<>();
	
	public void saveOrders(Orders orders) {
		
		listOrders.add(orders);
	
		
	}
	
	public Orders handleOrders(Orders orders) {
		for(int i = 0; i < listOrders.size(); i++) {
			Orders tempUser = listOrders.get(i);
			System.out.println("in handleLogin");
			if(tempUser.getPrice().equals(orders.getPrice()) && tempUser.getPrice().equals(orders.getPrice())) {
				return tempUser;
			}
		}
		return null;
	}
	


	
	
	
	public ArrayList<Orders> getUserList(){
		return listOrders;
	}

}
